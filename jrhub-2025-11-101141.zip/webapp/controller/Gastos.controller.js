sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/Dialog",
  "sap/m/Button",
  "sap/m/Label",
  "sap/m/Input",
  "sap/m/DatePicker",
  "sap/m/Select",
  "sap/ui/core/Item",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/ui/model/odata/v2/ODataModel"
], function (Controller, Dialog, Button, Label, Input, DatePicker, Select, Item, MessageToast, MessageBox, ODataModel) {
  "use strict";

  return Controller.extend("com.jr.jrhub.controller.Gastos", {


    onInit: function () {
      sap.ui.require(["com/jr/jrhub/localService/mockserver"], function (mockserver) {
        mockserver.init();

        //var oModel = new ODataModel("/localService/");
        //this.getView().setModel(oModel);
        //this.oModel = oModel;

        const sData = localStorage.getItem("gastosData");
        const oJSONModel = new sap.ui.model.json.JSONModel();
        this.oJSONModel = oJSONModel;


        if (sData) {
          const oParsed = JSON.parse(sData);
          const oConverted = oParsed.Gastos ? oParsed : { Gastos: oParsed };
          oJSONModel.setData(oConverted);
          this.getView().setModel(oJSONModel, "gastosLocal");
          this.oJSONModel = oJSONModel;
        }


        else {
          const sUrl = sap.ui.require.toUrl("com/jr/jrhub") + "/localService/mockdata/Gastos.json";
          console.log("URL generada:", sUrl);
          this.oJSONModel.loadData(sUrl);
          this.oJSONModel.attachRequestCompleted(() => {
            const aOriginal = this.oJSONModel.getProperty("/d/results") || [];
            const oConverted = { Gastos: aOriginal };

            oConverted.categorias = [
              { key: "", text: "Todas" },
              { key: "Comida", text: "Comida" },
              { key: "Transporte", text: "Transporte" },
              { key: "Ocio", text: "Ocio" },
              { key: "Otros", text: "Otros" }
            ];

            this.oJSONModel.setData(oConverted);

            console.log("Datos transformados:", this.oJSONModel.getProperty("/Gastos"));
            MessageToast.show("Registros cargados: " + this.oJSONModel.getProperty("/Gastos").length)

            localStorage.setItem("gastosData", JSON.stringify(oConverted));
            this.getView().setModel(this.oJSONModel, "gastosLocal");
          });

          this.oJSONModel.attachRequestFailed(() => {
            MessageToast.show("Error al cargar Gastos.json");
          });
        }
        console.log("Datos transformados:", this.oJSONModel.getProperty("/Gastos"));

      }.bind(this));
    },


    onExit: function () {
      // ✅ Detener MockServer al salir
      sap.ui.require(["com/jr/jrhub/localService/mockserver"], function (mockserver) {
        mockserver.stop();
      });
    },

    // ✅ Crear nuevo gasto
    onAddGasto: function () {
      if (!this._oDialog) {
        this._oDialog = new Dialog({
          title: "{i18n>dialogAddTitle}",
          contentWidth: "400px",
          content: [
            new Label({ text: "{i18n>colFecha}" }),
            new DatePicker("dpFecha", { valueFormat: "yyyy-MM-dd", displayFormat: "dd/MM/yyyy" }),

            new Label({ text: "{i18n>colCategoria}" }),
            new Select("selCategoria", {
              items: [
                new Item({ key: "Comida", text: "Comida" }),
                new Item({ key: "Transporte", text: "Transporte" }),
                new Item({ key: "Ocio", text: "Ocio" }),
                new Item({ key: "Otros", text: "Otros" })
              ]
            }),

            new Label({ text: "{i18n>colDescripcion}" }),
            new Input("inpDescripcion"),

            new Label({ text: "{i18n>colImporte}" }),
            new Input("inpImporte", { type: "Number" })
          ],
          beginButton: new Button({
            text: "{i18n>btnGuardar}",
            type: "Accept",
            press: this._onGuardarGasto.bind(this)
          }),
          endButton: new Button({
            text: "{i18n>btnCancelar}",
            type: "Reject",
            press: function () {
              this._oDialog.close();
            }.bind(this)
          })
        });

        this.getView().addDependent(this._oDialog);
      }

      this._oDialog.open();
    },

    _onGuardarGasto: function () {
      const fecha = sap.ui.getCore().byId("dpFecha").getValue();
      const categoria = sap.ui.getCore().byId("selCategoria").getSelectedKey();
      const descripcion = sap.ui.getCore().byId("inpDescripcion").getValue();
      const importe = parseFloat(sap.ui.getCore().byId("inpImporte").getValue());
      const aGastos = this.oJSONModel.getProperty("/Gastos") || [];
      const nuevoId = aGastos.length ? Math.max(...aGastos.map(g => g.id || 0)) + 1 : 1;

      const nuevoGasto = { id: nuevoId, fecha, categoria, descripcion, importe };
      aGastos.push(nuevoGasto);
      this.oJSONModel.setProperty("/Gastos", aGastos);
      localStorage.setItem("gastosData", JSON.stringify({ Gastos: aGastos }));

      if (!fecha || !categoria || !descripcion || isNaN(importe)) {
        MessageToast.show("Por favor, completa todos los campos.");
        return;
      }

      this.oModel.create("/Gastos", {
        fecha,
        categoria,
        descripcion,
        importe
      }, {
        success: () => {
          MessageToast.show("Gasto añadido correctamente.");
          this._oDialog.close();
        },
        error: () => MessageToast.show("Error al añadir gasto.")
      });
    },

    // ✅ Eliminar gasto

    onDeleteGasto: function (oEvent) {
      const oContext = oEvent.getSource().getBindingContext("gastosLocal");
      const sId = oContext.getProperty("id");

      MessageBox.confirm("¿Seguro que deseas eliminar este gasto?", {
        onClose: (oAction) => {
          if (oAction === MessageBox.Action.OK) {
            const aGastos = this.oJSONModel.getProperty("/Gastos");
            const aFiltrados = aGastos.filter(g => g.id !== parseInt(sId));
            this.oJSONModel.setProperty("/Gastos", aFiltrados);
            localStorage.setItem("gastosData", JSON.stringify({ Gastos: aFiltrados }));
            MessageToast.show("Gasto eliminado.");
          }
        }
      });
    },

    onFiltrarGastos: function () {
      const categoria = this.byId("selFiltroCategoria").getSelectedKey();
      const rangoFechas = this.byId("drFiltroFechas").getDateValue();
      const importeMin = parseFloat(this.byId("inpImporteMin").getValue()) || 0;
      const importeMax = parseFloat(this.byId("inpImporteMax").getValue()) || Infinity;

      let aGastos = this.oJSONModel.getProperty("/Gastos");

      // Filtrar por categoría
      if (categoria) {
        aGastos = aGastos.filter(g => g.categoria === categoria);
      }

      // Filtrar por importe
      aGastos = aGastos.filter(g => g.importe >= importeMin && g.importe <= importeMax);

      // Filtrar por fechas (si se selecciona rango)
      const fechaInicio = this.byId("drFiltroFechas").getDateValue();
      const fechaFin = this.byId("drFiltroFechas").getSecondDateValue();

      if (fechaInicio && fechaFin) {
        aGastos = aGastos.filter(g => {
          const fechaGasto = new Date(g.fecha);
          return fechaGasto >= fechaInicio && fechaGasto <= fechaFin;
        });
      }

      this.oJSONModel.setProperty("/GastosFiltrados", aGastos);
      this.byId("tblGastos").bindItems({
        path: "gastosLocal>/GastosFiltrados",
        template: this.byId("cliGasto").clone()
      });
    },

    _renderChart: function (aGastos) {
      const canvas = this.byId("chartContainer").getDomRef().querySelector("canvas");
      const ctx = canvas.getContext('2d');
      const categorias = ["Comida", "Transporte", "Ocio", "Otros"];
      const counts = categorias.map(cat => aGastos.filter(g => g.categoria === cat).length);

      this.byId("graficoGastos").setVizProperties({
        title: { text: "Gastos por Categoría" },
        plotArea: { colorPalette: ["#4caf50", "#2196f3", "#ff9800", "#9c27b0"] }
      });

      if (this._chart) {
        this._chart.destroy(); // Evitar duplicados
      }

      this._chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: categorias,
          datasets: [{
            label: 'Número de Gastos',
            data: counts,
            backgroundColor: ['#4caf50', '#2196f3', '#ff9800', '#9c27b0']
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { display: false },
            title: { display: true, text: 'Gastos por Categoría' }
          }
        }
      });
    }


  });
});
