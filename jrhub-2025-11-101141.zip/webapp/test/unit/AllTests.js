sap.ui.define([
	"com/jr/jrhub/test/unit/controller/App.controller"
], function () {
	"use strict";
});
