/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["com/jr/jrhub/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
